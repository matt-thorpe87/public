<pre>__PHP_Incomplete_Class Object
(
    [__PHP_Incomplete_Class_Name] => WP_Post
    [ID] => 13
    [post_author] => 1
    [post_date] => 2023-04-21 06:08:21
    [post_date_gmt] => 2023-04-21 01:52:59
    [post_content] => 
    [post_title] => Home
    [post_excerpt] => 
    [post_status] => publish
    [comment_status] => closed
    [ping_status] => closed
    [post_password] => 
    [post_name] => home
    [to_ping] => 
    [pinged] => 
    [post_modified] => 2023-04-21 06:08:21
    [post_modified_gmt] => 2023-04-21 06:08:21
    [post_content_filtered] => 
    [post_parent] => 0
    [guid] => http://csds-custom-theme.local/?p=13
    [menu_order] => 1
    [post_type] => nav_menu_item
    [post_mime_type] => 
    [comment_count] => 0
    [filter] => raw
    [db_id] => 13
    [menu_item_parent] => 0
    [object_id] => 13
    [object] => custom
    [type] => custom
    [type_label] => Custom Link
    [title] => Home
    [url] => http://csds-custom-theme.local/
    [target] => 
    [attr_title] => 
    [description] => 
    [classes] => Array
        (
            [0] => 
            [1] => menu-item
            [2] => menu-item-type-custom
            [3] => menu-item-object-custom
            [4] => menu-item-home
        )

    [xfn] => 
    [current] => 
    [current_item_ancestor] => 
    [current_item_parent] => 
)
</pre>