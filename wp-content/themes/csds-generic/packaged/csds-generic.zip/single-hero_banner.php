<?php 
/*
Template name: hero banner
*/
get_header();
get_template_part( 'template_parts/hero_banner' ); 
get_footer();