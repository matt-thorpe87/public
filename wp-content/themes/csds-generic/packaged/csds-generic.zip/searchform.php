<form action="/" method="get" class="qld__search__inner">
    <!-- <label for="search">Search website
    </label> -->
    <input type="text" name="s" class="qld__text-input" id="search" value="<?php the_search_query(); ?>" />
    <button type="submit" class="qld__btn qld__btn--search"><span>Search</span></button>
</form>